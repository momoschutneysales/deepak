MOMOS CHUTNEY — RENDER DEPLOYMENT

1. Upload all files to a PRIVATE GitHub repository.
2. In Render: New > Web Service > connect the GitHub repository.
3. Runtime/Language: Node.
4. Build Command: npm install
5. Start Command: npm start
6. Plan: Free for testing.
7. Add these Environment Variables in Render:
   RAZORPAY_KEY_ID
   RAZORPAY_KEY_SECRET
   RAZORPAY_WEBHOOK_SECRET
   RESEND_API_KEY
   FROM_EMAIL

8. In Razorpay Dashboard configure a webhook:
   https://YOUR-RENDER-URL/webhook/razorpay
   Subscribe to payment.captured.

IMPORTANT:
- Never put Razorpay Secret or Resend API key in HTML or GitHub.
- Render Free services can sleep after inactivity and have other limitations.
- For production sales, move to a paid hosting plan/domain after testing.
