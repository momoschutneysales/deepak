const express = require("express");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const { Resend } = require("resend");

const app = express();
const PORT = process.env.PORT || 10000;

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

const resend = process.env.RESEND_API_KEY
  ? new Resend(process.env.RESEND_API_KEY)
  : null;

const PDF_PATH = path.join(
  __dirname,
  "private",
  "3-Signature-Momos-Chutney-Recipes.pdf"
);

// Razorpay webhook must receive the raw body.
app.post(
  "/webhook/razorpay",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    try {
      const signature = req.headers["x-razorpay-signature"];
      const secret = process.env.RAZORPAY_WEBHOOK_SECRET;

      if (!signature || !secret) return res.status(400).send("Missing webhook config");

      const expected = crypto
        .createHmac("sha256", secret)
        .update(req.body)
        .digest("hex");

      if (
        expected.length !== signature.length ||
        !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))
      ) {
        return res.status(400).send("Invalid signature");
      }

      const event = JSON.parse(req.body.toString("utf8"));

      if (event.event !== "payment.captured") {
        return res.status(200).send("Ignored");
      }

      const payment = event.payload?.payment?.entity;
      const email = payment?.email;

      if (!email) return res.status(200).send("Captured; email unavailable");

      if (!resend) {
        console.log("Payment captured but RESEND_API_KEY is not configured.");
        return res.status(200).send("Captured; email not configured");
      }

      if (!fs.existsSync(PDF_PATH)) {
        throw new Error("Recipe PDF missing");
      }

      const attachment = fs.readFileSync(PDF_PATH).toString("base64");

      await resend.emails.send({
        from: process.env.FROM_EMAIL || "onboarding@resend.dev",
        to: [email],
        subject: "Your 3 Signature Momos Chutney Recipes",
        html: "<p>Thank you for your purchase.</p><p>Your 3 Signature Momos Chutney Recipes PDF is attached.</p>",
        attachments: [
          {
            content: attachment,
            filename: "3-Signature-Momos-Chutney-Recipes.pdf",
          },
        ],
      });

      return res.status(200).send("Delivered");
    } catch (err) {
      console.error(err);
      return res.status(500).send("Webhook error");
    }
  }
);

app.use(express.json());

// Create a Razorpay order.
app.get("/create-order", async (req, res) => {
  try {
    const order = await razorpay.orders.create({
      amount: 39900,
      currency: "INR",
      receipt: `momos_${Date.now()}`,
      notes: { product: "3 Signature Momos Chutney Recipes" },
    });

    res.send(`<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Secure Checkout</title></head>
<body style="font-family:Arial;text-align:center;padding:40px">
<h2>3 Signature Momos Chutney Recipes</h2>
<p>Amount: ₹399</p>
<button id="pay" style="padding:16px 30px;font-size:18px">Pay ₹399</button>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
document.getElementById("pay").onclick = function () {
  const options = {
    key: ${JSON.stringify(process.env.RAZORPAY_KEY_ID)},
    amount: 39900,
    currency: "INR",
    name: "Dawa Norki",
    description: "3 Signature Momos Chutney Recipes",
    order_id: ${JSON.stringify(order.id)},
    handler: function (response) {
      window.location.href =
        "/payment-success?payment_id=" +
        encodeURIComponent(response.razorpay_payment_id) +
        "&order_id=" +
        encodeURIComponent(response.razorpay_order_id);
    },
    theme: { color: "#e11b17" }
  };
  new Razorpay(options).open();
};
</script></body></html>`);
  } catch (err) {
    console.error(err);
    res.status(500).send("Unable to create payment order");
  }
});

app.get("/payment-success", (req, res) => {
  res.send(`<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Payment Successful</title></head>
<body style="font-family:Arial;text-align:center;padding:40px">
<h1>Thank you! 🎉</h1>
<p>Your payment has been received.</p>
<p>Your Momos Chutney recipe PDF will be sent to the email address used during payment.</p>
<p>You can close this page.</p>
<script>
if (typeof fbq === "function") {
  fbq('track', 'Purchase', {value:399, currency:'INR'});
}
</script>
</body></html>`);
});

// Serve landing page.
app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Momos Chutney app running on port ${PORT}`);
});
